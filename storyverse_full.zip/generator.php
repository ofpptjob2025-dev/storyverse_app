<?php include('config/db.php'); if($_POST){
$title=$_POST['title'];$content=$_POST['content'];
$img='https://picsum.photos/600/300';
$uid=$_SESSION['user']['id'];
$conn->query("INSERT INTO stories(user_id,title,content,image_url) VALUES($uid,'$title','$content','$img')");
}
?>
<link rel='stylesheet' href='assets/style.css'>
<div class='container'>
<form method='POST'>
<input name='title'>
<textarea name='content'></textarea>
<button>Generate</button>
</form>
</div>
