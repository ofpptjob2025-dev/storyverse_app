<?php include('config/db.php'); if($_POST){
$u=$_POST['username'];$e=$_POST['email'];$p=password_hash($_POST['password'],PASSWORD_DEFAULT);
$conn->query("INSERT INTO users(username,email,password) VALUES('$u','$e','$p')");
}
?>
<link rel='stylesheet' href='assets/style.css'>
<div class='container'>
<form method='POST'>
<input name='username' placeholder='Username'>
<input name='email' placeholder='Email'>
<input type='password' name='password'>
<button>Register</button>
</form></div>
