<?php include('config/db.php');$id=$_GET['id'];
$s=$conn->query("SELECT * FROM stories WHERE id=$id")->fetch_assoc();
?>
<link rel='stylesheet' href='assets/style.css'>
<div class='container'>
<h1><?= $s['title']?></h1>
<img src='<?= $s['image_url']?>' width='100%'>
<p><?= $s['content']?></p>
<form method='POST'><input name='comment'><button>Add</button></form>
</div>
