<?php include('config/db.php');?>
<link rel='stylesheet' href='assets/style.css'>
<div class='container'>
<h1>🌌 StoryVerse AI</h1>
<a href='login.php'>Login</a> | <a href='register.php'>Register</a>
<h2>Stories</h2>
<?php $res=$conn->query("SELECT * FROM stories"); while($s=$res->fetch_assoc()){ ?>
<div class='card'>
<h3><?= $s['title'] ?></h3>
<a href='story.php?id=<?= $s['id'] ?>'>Read</a>
</div>
<?php } ?>
</div>
