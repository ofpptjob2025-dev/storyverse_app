<?php
$conn = new mysqli('localhost','root','','storyverse');
session_start();
?>