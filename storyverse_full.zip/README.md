StoryVerse AI Full SaaS Starter
Run in XAMPP, import database.sql