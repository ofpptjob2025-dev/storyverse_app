<?php include('config/db.php');?>
<link rel='stylesheet' href='assets/style.css'>
<div class='container'>
<h2>Dashboard</h2>
<a href='generator.php'>Generate Story</a> |
<a href='library.php'>Library</a>
</div>
