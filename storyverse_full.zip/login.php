<?php include('config/db.php'); if($_POST){
$e=$_POST['email'];$p=$_POST['password'];
$r=$conn->query("SELECT * FROM users WHERE email='$e'");$u=$r->fetch_assoc();
if($u && password_verify($p,$u['password'])){$_SESSION['user']=$u; header('Location:dashboard.php');}
}
?>
<link rel='stylesheet' href='assets/style.css'>
<div class='container'>
<form method='POST'>
<input name='email'>
<input type='password' name='password'>
<button>Login</button>
</form>
</div>
