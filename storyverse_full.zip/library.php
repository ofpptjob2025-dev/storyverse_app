<?php include('config/db.php');?>
<link rel='stylesheet' href='assets/style.css'>
<div class='container'>
<h2>Library</h2>
<?php $res=$conn->query("SELECT * FROM stories"); while($s=$res->fetch_assoc()){?>
<div class='card'>
<?= $s['title']?> <a href='story.php?id=<?= $s['id']?>'>Open</a>
</div>
<?php }?>
</div>
